import pandas as pd
import smtplib
import os
from email.message import EmailMessage

# ---- CONFIGURATION ----
EMAIL_ADDRESS = "shantanujaipurkar99@gmail.com"
APP_PASSWORD = "vxyy stwp eena tzvu"
EXCEL_FILE = "Recruitor_Details.xlsx"
RESUME_FILE = "Shantanu Jaipurkar.pdf"
LOG_FILE = "sent_log.csv"
GITHUB_LINK = "https://github.com/Shantanujpk"
PHONE_NUMBER = "(862)-410-1881"

# ---- LOAD DATA ----
df = pd.read_excel(EXCEL_FILE)

# Load or create log file
if os.path.exists(LOG_FILE):
    sent_log = pd.read_csv(LOG_FILE, usecols=["Company", "Job ID"], dtype=str)
else:
    sent_log = pd.DataFrame(columns=['Company', 'Job ID'])

# ---- EMAIL FUNCTION ----
def send_email(to_email, subject, body, attachment_path):
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = f"Shantanu Jaipurkar <{EMAIL_ADDRESS}>"
    msg['To'] = to_email

    msg.set_content(body)
    html_body = body.replace('\n', '<br>')
    msg.add_alternative(f"""
    <html>
      <body style='font-family: Arial, sans-serif; font-size: 14px; color: #000;'>
        {html_body}
      </body>
    </html>
    """, subtype='html')

    with open(attachment_path, 'rb') as f:
        msg.add_attachment(f.read(), maintype='application', subtype='octet-stream', filename=os.path.basename(attachment_path))

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(EMAIL_ADDRESS, APP_PASSWORD)
        smtp.send_message(msg)

# ---- EMAIL GENERATION FUNCTION ----
def generate_email(row):
    company = row['Company']
    recruiter_name = row['Recruiter_Name']
    role = row['Role']
    email = row['Email']

    # Clean job ID formatting
    raw_job_id = row.get('Job ID', '')
    if isinstance(raw_job_id, float) and raw_job_id.is_integer():
        job_id = str(int(raw_job_id))
    else:
        job_id = str(raw_job_id).strip()

    location = str(row.get('Location', 'N/A')).strip()
    company_work = str(row.get('Company_Work', '')).strip()
    job_link = str(row.get('Link', '')).strip()

    company_line = f"I've been following {company} and I'm genuinely intrigued by the work doing in {company_work}. It feels innovative, purposeful, and exactly the kind of environment I’m eager to contribute to.\n" if company_work else ""
    reason_line = f"The reason I’m reaching out is because there is an opening of {role} – {job_id} at your company, and I think I will be a perfect fit for the same considering my experience, projects, job responsibilities and qualification.\n" if role and job_id else ""
    job_link_line = f"Job Link: {job_link}\n" if job_link else ""

    about_me = f"""
A little bit about me:

At Infosys:
1. Helped CareFirst in data analysis for shifting from a legacy system to AWS cloud infrastructure (TIBCO to AWS).
2. Conducted SQL analysis of healthcare claim files to provide precise insurance results.
3. Built data visualization dashboards using AWS QuickSight for plan and trend analysis.

At Binghamton University:
1. Created dashboards to examine traffic trends and scripted Excel macros to prevent manual data entry.
2. Performed data profiling and validation using Python and Pandas on weekly traffic data sets to ensure the quality of the data.

At Persistent Systems:
1. Maintained vehicle metadata pipelines in operation using PySpark, Python, and SQL.
2. Supported the development team in structured data used in vehicle damage detection algorithms.
"""

    project_intro = "The data analysis and engineering projects I’ve worked on are summarized below:\n"

    project_lines = [
        "• Built a secure data pipeline from AWS S3 to Snowflake using SQL and IAM roles in the FrostFlow project, boosting real-time analytics speed by 40%.",
        "• Developed Power BI dashboards using DAX and Power Query in the Car Sale Insights project, reducing manual reporting by 10% and enabling regional sales analysis.",
        "• Developed a stock trend prediction model in Python using AI/ML, improving accuracy and reducing RMSE by 18%."
    ]

    skillset_summary = "My core technical skills include: Python, SQL, PySpark, Snowflake, AWS S3, AWS QuickSight, PowerBI, and TIBCO."

    body = f"""Hi {recruiter_name},

My name is Shantanu Jaipurkar. I recently completed my Master’s degree in Information Systems and bring 3 years of experience in the data industry.

{company_line}{reason_line}{job_link_line}
{about_me}
{skillset_summary}

{project_intro}
{chr(10).join(project_lines)}

I’d be grateful for the opportunity to connect and learn more about the {role} opening or any related opportunities at {company}.

It would be incredibly meaningful for me to contribute to {company}'s mission and help drive data impact from day one.

I’ve attached my resume for your review, and you can also explore my GitHub: {GITHUB_LINK}.

Looking forward to hearing from you.

Best regards,  
Shantanu Jaipurkar  
📧 {EMAIL_ADDRESS} | 📞 {PHONE_NUMBER}"""

    return email, f"Application for {role} at {company}", body

# ---- MAIN LOOP ----
new_entries = []
for idx, row in df.iterrows():
    company = str(row['Company']).strip()
    job_id = str(row.get('Job ID', '')).strip()

    already_sent = (
        (sent_log['Company'].astype(str).str.strip() == company) &
        (sent_log['Job ID'].astype(str).str.strip() == job_id)
    ).any()

    if already_sent:
        print(f"⚠️ Already sent for Job ID: {job_id} at {company} — Skipping.")
        continue

    try:
        to_email, subject, body = generate_email(row)
        send_email(to_email, subject, body, RESUME_FILE)
        print(f"✅ Email sent to {row['Recruiter_Name']} ({to_email}) for role: {row['Role']}")

        new_entries.append({
            'Company': company,
            'Job ID': job_id
        })

    except Exception as e:
        print(f"❌ Failed to send to {row['Email']}: {e}")

# ---- SAVE LOG ----
if new_entries:
    sent_log = pd.concat([sent_log, pd.DataFrame(new_entries)], ignore_index=True)
    try:
        sent_log.to_csv(LOG_FILE, index=False)
    except PermissionError:
        print(f"❌ Unable to write to log file. Please close {LOG_FILE} if it's open in another program.")
